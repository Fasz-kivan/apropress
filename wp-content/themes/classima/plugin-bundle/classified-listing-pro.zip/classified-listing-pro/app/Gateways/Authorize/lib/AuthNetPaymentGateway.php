<?php

namespace RtclPro\Gateways\Authorize\lib;

use Rtcl\Models\PaymentGateway;

class AuthNetPaymentGateway extends PaymentGateway {

}
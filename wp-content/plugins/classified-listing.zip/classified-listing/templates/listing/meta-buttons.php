<?php
/**
 * Listing meta
 *
 * @author     RadiusTheme
 * @package    classified-listing/templates
 * @version    1.0.0
 */

global $listing;
?>
<div class="rtcl-meta-buttons"><?php do_action('rtcl_listing_meta_buttons', $listing); ?></div>


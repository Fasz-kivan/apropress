<?php
/**
 *
 * @author        RadiusTheme
 * @package       classified-listing/templates
 * @version       1.0.0
 * @deprecated
 */

use Rtcl\Helpers\Functions;

_deprecated_file(__FILE__, '2.0.0', 'Functions::get_template("listing/badges")');

Functions::get_template("listing/badges");
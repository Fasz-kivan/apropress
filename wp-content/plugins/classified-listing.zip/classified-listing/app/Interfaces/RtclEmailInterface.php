<?php

namespace Rtcl\Interfaces;

interface RtclEmailInterface
{
    public function trigger($listing_id);
}
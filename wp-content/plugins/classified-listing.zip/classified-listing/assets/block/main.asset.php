<?php return array('dependencies' => array('jquery', 'react', 'react-dom', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '336392d2ac859dc51159');

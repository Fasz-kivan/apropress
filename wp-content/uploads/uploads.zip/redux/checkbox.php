<?php
   class Redux_Customizer_Control_checkbox extends Redux_Customizer_Control {
     public $type = "redux-checkbox";
   }